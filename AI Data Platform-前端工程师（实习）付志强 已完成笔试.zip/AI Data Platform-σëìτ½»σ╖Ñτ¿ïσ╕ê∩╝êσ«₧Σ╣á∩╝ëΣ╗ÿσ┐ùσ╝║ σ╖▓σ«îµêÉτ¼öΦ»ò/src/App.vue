<template>
  <div>
    <Comp />
  </div>
</template>

<script>
import Comp from "./components/Datepicker.vue";
export default {
  components: {
    Comp,
  },
};
</script>

<style></style>
